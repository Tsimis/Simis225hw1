public class parkingSpot {
    public boolean handicap;
    public boolean carParked;

    public parkingSpot(boolean handicap, boolean carParked){
        this.handicap=handicap;
        this.carParked=carParked;
    }
}
