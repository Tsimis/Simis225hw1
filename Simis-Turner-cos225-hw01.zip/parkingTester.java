public class parkingTester {
    public static void main(String[] args){
        parkingLot ParkingLot = new parkingLot();
        System.out.println(ParkingLot.toString());
        car Infinity = new car("Infiniti","A",true);
        ParkingLot.parkedInSpot(Infinity);
        System.out.println(ParkingLot.toString());
        car Cadilac = new car("cadilac","B",false);
        ParkingLot.parkedInSpot(Cadilac);
        System.out.println(ParkingLot.toString());
        ParkingLot.RemoveCar(0);
        System.out.println(ParkingLot.toString());
        }
}
