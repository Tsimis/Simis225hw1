public class car {
    public String make;
    public String model;
    public boolean handicap;

    public car(String make, String model, boolean handicap){
        this.make=make;
        this.model=model;
        this.handicap=handicap;
    }
}
