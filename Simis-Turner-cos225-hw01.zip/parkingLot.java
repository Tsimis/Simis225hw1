public class parkingLot {
    public parkingSpot[] spots;

    public parkingLot (){
        this.spots = new parkingSpot[10];
        this.spots[0]= new parkingSpot(true,false);
            for (int i = 0; i < 2; i++){
                spots[i] = new parkingSpot(true,false);
            }
            for ( int i =2; i < 10;i++){
                spots[i] = new parkingSpot(false,false);
            }
    }
    public int parkedInSpot (car car) {
        int spotNum=20;
        for ( int i =0; i < 10;i++){
            if (car.handicap == true && spots[i].handicap==true && spots[i].carParked==false){
                spots[i].carParked=true;
                spotNum=i;
                return spotNum;
            }
            if (car.handicap != true && spots[i].handicap!=true && spots[i].carParked==false){
                spots[i].carParked=true;
                spotNum=i;
                return spotNum;
            }
    }   
    return spotNum;
}
    public int RemoveCar(int index){
        spots[index].carParked=false;
        return 0;
    }
/*
    public car carInSpot(int num) {
        if (this.spots[num].carParked==true);
            return this.spots[num].model;
    } 
*/
    public String toString() {
        int HandicapCounter = 0;
        int RegCounter = 0;
        for  ( int i =0; i < 10;i++){
            if (this.spots[i].handicap==true && this.spots[i].carParked==false) {
                HandicapCounter++;
            }
            if (this.spots[i].handicap==false && this.spots[i].carParked==false){
                RegCounter++;
            }
        } 
        return HandicapCounter+" "+RegCounter;
    }
}
